import { Menu } from "../../../shared/entities/Menu";
import { useEffect, useState } from 'react';
import { Spinner } from "../spinner";
import Image from "next/image";
import { repo } from 'remult';
import { ErrorInfo } from "../Error";
import classes from './one-dish.module.css';


export function OneDish({ dishId }: { dishId: number | undefined }) {
    const
        [loading, setLoading] = useState(true),
        [error, setError] = useState(null),
        [data, setData] = useState<Menu[]>([]);
    useEffect(() => {
        repo(Menu)
            .find(
                {
                    where: { id: dishId }
                })
            .then(setData)
            .catch(setError)
            .finally(() => setLoading(false));
    }, []);

    if (error) return <ErrorInfo error={error} />

    return <>
        {loading ? <Spinner /> :
            <div className={classes.dish}> 

                {data?.map(menus => <fieldset key={menus.id}><p>{menus.name}</p><p>КБЖУ:{menus.energy}</p>
                    <Image src={"/" + menus?.photo} width={100} height={100} alt="Picture of the author" />
                    <br /> Рецепт: <p>{menus.recipe}</p>
                    <button 
                    // onClick={addMenuByUser(menus.id)} 
                    > Удалить из моего меню </button>
                </fieldset>)}
            </div>
        }
    </>

}
