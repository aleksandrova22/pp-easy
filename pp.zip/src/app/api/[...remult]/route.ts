import { api } from "../../../server/api";

export const { POST, PUT, DELETE, GET } = api;
