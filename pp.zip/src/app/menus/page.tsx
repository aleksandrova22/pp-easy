"use client"
// рецепты

import { GetMenu } from "@/components/Menu/get-menu"



export default function PageMenu() {
    return <>
        <h1>Рецепты к рассчетом КБЖУ</h1>
        <GetMenu />

    </>
}
