import Image from "next/image";

export default function PageContact() {
  
    return <>
      <h1>Обратная связь</h1>
      <hr /> 
      {/* <Image src={"/" + "ig.png"} width={30} height={30} alt="Picture of the author" > <a href="https://t.me/elena_lyamurka" /> </Image> */}
    
      {/* <div> <DemoUsers users={users} /> </div> */}
     
    </>
  }
 