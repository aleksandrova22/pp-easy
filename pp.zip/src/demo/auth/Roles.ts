export const Roles = {
  admin: "admin",
};
